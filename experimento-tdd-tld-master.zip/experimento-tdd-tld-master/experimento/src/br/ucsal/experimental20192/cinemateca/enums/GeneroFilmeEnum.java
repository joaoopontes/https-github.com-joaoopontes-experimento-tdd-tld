package br.ucsal.experimental20192.cinemateca.enums;

public enum GeneroFilmeEnum {
	ACAO, AVENTURA, COMEDIA, TERROR
}
