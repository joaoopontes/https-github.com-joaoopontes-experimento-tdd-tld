package br.ucsal.experimental20192.cinemateca.enums;

public enum GeneroAtorEnum {
	FEMININO, MASCULINO
}
